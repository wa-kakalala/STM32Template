#ifndef _DIGITALTUBE_H_
#define _DIGITALTUBE_H_
#include "stm32f4xx.h"
#include "stm32f4xx_rcc.h"
#include "stm32f4xx_gpio.h"

#define TUBE_RCC_A RCC_AHB1Periph_GPIOA
#define TUBE_RCC_B RCC_AHB1Periph_GPIOB

// PORT B
#define TUBE_S1  GPIO_Pin_12     
#define TUBE_S2  GPIO_Pin_15   

#define TUBE_A   GPIO_Pin_13
#define TUBE_C   GPIO_Pin_0
#define TUBE_D	 GPIO_Pin_2
#define TUBE_E   GPIO_Pin_10
#define TUBE_F   GPIO_Pin_14
#define TUBE_DP  GPIO_Pin_1
    
// PORT A
#define TUBE_S3  GPIO_Pin_8 
#define TUBE_S4  GPIO_Pin_6

#define TUBE_B   GPIO_Pin_9
#define TUBE_G   GPIO_Pin_7

#define TUBE_PORT_A  GPIOA
#define TUBE_PORT_B  GPIOB

void DigitalTube_Init(void);
void DigitalTube_SetNumber(uint8_t number);
void DigitalTube_ChoiceTube(uint8_t number);

#endif

