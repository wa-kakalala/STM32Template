#include "digitaltube.h"


void DigitalTube_Init(){
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_AHB1PeriphClockCmd(TUBE_RCC_A, ENABLE);
	RCC_AHB1PeriphClockCmd(TUBE_RCC_B, ENABLE);
	
    GPIO_StructInit(&GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin = TUBE_S3 | TUBE_S4 | TUBE_B | TUBE_G;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_25MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL ;
    GPIO_Init(TUBE_PORT_A, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = TUBE_S1 | TUBE_S2 | TUBE_A | TUBE_C | TUBE_D | TUBE_E | TUBE_F | TUBE_DP;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_25MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL ;
    GPIO_Init(TUBE_PORT_B, &GPIO_InitStructure);
	
	GPIO_ResetBits(TUBE_PORT_A,TUBE_S3 | TUBE_S4 | TUBE_B | TUBE_G);
	GPIO_ResetBits(TUBE_PORT_B,TUBE_S1 | TUBE_S2 | TUBE_A | TUBE_C | TUBE_D | TUBE_E | TUBE_F | TUBE_DP);
}

uint16_t TUBE_PIN_ARR[] = {
		TUBE_A,
		TUBE_B,
		TUBE_C,
		TUBE_D,
		TUBE_E,
		TUBE_F,
		TUBE_G,
		TUBE_DP
};
	
// 0  TUBE_PORT_A
// 1  TUBE_PORT_B
uint8_t TUBE_PIN_PORT[] = {
		1,
		0,
		1,
		1,
		1,
		1,
		0,
		1
};

uint8_t TUBE_PIN_CODE[] = {
	// a --> g dp
	0xfc,
	0x0c,
	0xda,
	0xf2,
	0x66,
	0xb6,
	0xbe,
	0xe0,
	0xfe,
	0xf6,
	0x00,      // all off
};

void DigitalTube_SetNumber(uint8_t number){
	uint8_t code = TUBE_PIN_CODE[number];
	uint8_t index = 0;
	for(index = 0;index<8;index++){
		if(code & 0x01){
			GPIO_SetBits(TUBE_PIN_PORT[7-index]?TUBE_PORT_B:TUBE_PORT_A,
			               TUBE_PIN_ARR[7-index]);
		}else{
			GPIO_ResetBits(TUBE_PIN_PORT[7-index]?TUBE_PORT_B:TUBE_PORT_A,
			               TUBE_PIN_ARR[7-index]);
		}
		code = code >> 1;
	}
}


uint8_t TUBE_GND_PORT[] = {
		1,
		1,
		0,
		0
};

uint16_t TUBE_GND_ARR[] = {
		TUBE_S1,
		TUBE_S2,
		TUBE_S3,
		TUBE_S4
};

// xxxx bit s1 -> s4
void DigitalTube_ChoiceTube(uint8_t number){
	uint8_t index = 0;
	for(index = 0;index<4;index++){
		if(number & 0x01){
			GPIO_ResetBits(TUBE_GND_PORT[3-index]?TUBE_PORT_B:TUBE_PORT_A,
			               TUBE_GND_ARR[3-index]);
		}else{
			GPIO_SetBits(TUBE_GND_PORT[3-index]?TUBE_PORT_B:TUBE_PORT_A,
			               TUBE_GND_ARR[3-index]);
		}
		number = number >> 1;
	}
}
