#ifndef _SYSTICK_H_
#define _SYSTICK_H_
#include "misc.h"


void Delay_ms(uint32_t nTime);
void SysTickInit(void);
#endif

